
# PASIYA-MD - WhatsApp Bot Website

This is a simple business website for PASIYA-MD, built using HTML, CSS, and JS.

## Pages Included
- Home
- About
- Contact (with WhatsApp button)
- Register

## How to Deploy

1. Go to https://vercel.com or https://netlify.com
2. Sign in with GitHub or Email
3. Click "New Project" and upload this folder
4. Site will be live within seconds (e.g., pasiya-md.vercel.app)

You can also host with GitHub Pages.
