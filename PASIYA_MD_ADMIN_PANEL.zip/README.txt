
# PASIYA-MD Admin Panel

This is a basic admin panel for PASIYA-MD site.

## Pages:
- login.html (Username: admin | Password: pasiya123)
- dashboard.html (View registered users)
- leads.html (Track WhatsApp clicks)

## Hosting Suggestion:
Host on Netlify or Vercel same as main site.
